import './PopUp.style.css';

const PopUp = ({
    styles,

}) => {

    /* ===== RENDER ===== */
    return (
        <div>

        </div>
    );
}

export default PopUp;